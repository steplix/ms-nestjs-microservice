module.exports = {
  "*.{js,ts}": ["eslint --fix", "eslint"],
  "**/*.ts": () => "npm run build-types",
  "*.json": ["prettier --write"],
};
