import { App as BaseApp } from "@steplix/microservice";
import { AppModule } from "./app.module";

export class App extends BaseApp {
  // eslint-disable-next-line require-jsdoc
  getAppModule() {
    return AppModule;
  }
}
