import { Module } from "@nestjs/common";
import { AppModule as BaseAppModule } from "@steplix/microservice";
import { moduleOptions } from "@steplix/microservice/app.module.options";
import { CountriesModule, CitiesModule } from "./modules";

// Import controllers modules
moduleOptions.imports.push(CountriesModule);
moduleOptions.imports.push(CitiesModule);

@Module(moduleOptions)
export class AppModule extends BaseAppModule {}
