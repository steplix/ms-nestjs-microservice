// prevent no exists cache configuration
process.env.CACHE_ENABLED = "true";

// imports
import { App } from "./app";

// Create nest application instance
const app = new App();

// Bootstrap application
app.bootstrap();
