import {
  Table,
  Column,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
} from "sequelize-typescript";
import { ApiProperty } from "@nestjs/swagger";
import { Model } from "@steplix/microservice";
import Status from "./status";
import Department from "./department";

@Table({ tableName: "countries", timestamps: false })
export default class Country extends Model<Country> {
  //
  // properties
  //

  @ApiProperty({ description: "Unique identifier" })
  @PrimaryKey
  @Column
  id: number;

  @ApiProperty({ description: "Unique Status identifier" })
  @ForeignKey(() => Status)
  @Column({ field: "status_id" })
  statusId: number;

  @ApiProperty({ description: "Country description" })
  @Column
  description: string;

  @ApiProperty({ description: "Country created date at" })
  @CreatedAt
  @Column({ field: "created_at" })
  createdAt?: Date;

  @ApiProperty({ description: "Country updated date at" })
  @UpdatedAt
  @Column({ field: "updated_at" })
  updatedAt?: Date;

  //
  // relationships
  //

  @BelongsTo(() => Status)
  status: Status;

  @HasMany(() => Department)
  departments: Department[];
}
