import { Model, Table, Column, PrimaryKey, HasMany } from "sequelize-typescript";
import { ApiProperty } from "@nestjs/swagger";


@Table({ tableName: "statuses", timestamps: false })
export default class Status extends Model<Status> {
  //
  // properties
  //

  @ApiProperty({ description: "Unique identifier" })
  @PrimaryKey
  @Column
  id: number;

  @ApiProperty({ description: "Status description" })
  @Column
  description: string;
}
