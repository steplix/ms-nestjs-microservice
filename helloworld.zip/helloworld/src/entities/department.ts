import {
  Table,
  Column,
  PrimaryKey,
  ForeignKey,
  BelongsTo,
  HasMany,
  CreatedAt,
  UpdatedAt,
} from "sequelize-typescript";
import { ApiProperty } from "@nestjs/swagger";
import { Model } from "@steplix/microservice";
import Country from "./country";
import Status from "./status";
import City from "./city";

@Table({ tableName: "departments", timestamps: false })
export default class Department extends Model<Department> {
  //
  // properties
  //

  @ApiProperty({ description: "Unique identifier" })
  @PrimaryKey
  @Column
  id: number;

  @ApiProperty({ description: "Unique Country identifier" })
  @ForeignKey(() => Country)
  @Column({ field: "country_id" })
  countryId?: number;

  @ApiProperty({ description: "Unique Status identifier" })
  @ForeignKey(() => Status)
  @Column({ field: "status_id" })
  statusId: number;

  @ApiProperty({ description: "Department description" })
  @Column
  description?: string;

  @ApiProperty({ description: "Department created date at" })
  @CreatedAt
  @Column({ field: "created_at" })
  createdAt?: Date;

  @ApiProperty({ description: "Department updated date at" })
  @UpdatedAt
  @Column({ field: "updated_at" })
  updatedAt?: Date;

  //
  // relationships
  //

  @BelongsTo(() => Country)
  country: Country;

  @HasMany(() => City)
  cities: City[];

  @BelongsTo(() => Status)
  status: Status;
}
