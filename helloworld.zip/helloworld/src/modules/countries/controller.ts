import {
  ApiTags,
  ApiConsumes,
  ApiProduces,
  ApiResponse,
  ApiOperation,
  ApiParam,
} from "@nestjs/swagger";
import { Controller, HttpStatus, HttpException, Get, Query, Param } from "@nestjs/common";
import { FinderDto, GetterByIdDto, isInteger } from "@steplix/microservice";
import { Country } from "@app/entities";
import { CountriesService } from "./service";

//
// class
//

// Swagger documentation
@ApiTags("countries")
@ApiConsumes("application/json")
@ApiProduces("application/json")
// Controller name
@Controller("v1/countries")
export class CountriesController {
  constructor(private readonly countriesService: CountriesService) {}

  /**
   * Find Countries
   */

  // Method and Path
  @Get()
  // Swagger documentation
  @ApiOperation({ summary: "Get Countries" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Countries",
    type: Country,
  })
  // Interceptors
  async find(@Query() query: FinderDto) {
    // Bussiness logic
    return await this.countriesService.find(query);
  }

  /**
   * Get Country by ID
   */

  // Method and Path
  @Get(":id")
  // Swagger documentation
  @ApiOperation({ summary: "Get Country by ID" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country by id",
    type: Country,
  })
  @ApiParam({ name: "id", example: "1" })
  async getById(@Param("id") id: string, @Query() query: GetterByIdDto) {
    // Validation
    if (!id || !isInteger(id)) {
      throw new HttpException("Invalid ID", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    const result = await this.countriesService.getById(Number(id), query);

    if (!result) {
      throw new HttpException("Country not found", HttpStatus.NOT_FOUND);
    }
    return result;
  }
}
