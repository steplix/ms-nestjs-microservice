import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import {
  City,
  Country,
  Department,
  Status,
} from "@app/entities";
import { CountryDepartmentsController } from "./controller";
import { CountryDepartmentsService } from "./service";
import { CountryDepartmentCitiesModule } from "./cities";

@Module({
  imports: [
    // sub-modules
    CountryDepartmentCitiesModule,

    // db models
    SequelizeModule.forFeature([
      City,
      Country,
      Department,
      Status,
    ]),
  ],
  providers: [CountryDepartmentsService],
  controllers: [CountryDepartmentsController],
})
export class CountryDepartmentsModule {}
