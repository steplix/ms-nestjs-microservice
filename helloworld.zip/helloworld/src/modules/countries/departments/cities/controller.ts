import {
  ApiTags,
  ApiConsumes,
  ApiProduces,
  ApiResponse,
  ApiOperation,
  ApiParam,
} from "@nestjs/swagger";
import { Controller, HttpStatus, HttpException, Get, Query, Param } from "@nestjs/common";
import { FinderDto, GetterByIdDto, isInteger } from "@steplix/microservice";
import { City } from "@app/entities";
import { CountryDepartmentCitiesService } from "./service";

//
// class
//

// Swagger documentation
@ApiTags("country department cities")
@ApiConsumes("application/json")
@ApiProduces("application/json")
// Controller name
@Controller("v1/countries/:countryId/departments/:departmentId/cities")
export class CountryDepartmentCitiesController {
  constructor(private readonly countryDepartmentCitiesService: CountryDepartmentCitiesService) {}

  /**
   * Find Country Department Cities
   */

  // Method and Path
  @Get()
  // Swagger documentation
  @ApiOperation({ summary: "Get Country Department Cities" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country Department Cities",
    type: City,
  })
  // Interceptors
  async find(
    @Param("countryId") countryId: string,
    @Param("departmentId") departmentId: string,
    @Query() query: FinderDto
  ) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }
    if (!departmentId || !isInteger(departmentId)) {
      throw new HttpException("Invalid ID Department", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    return await this.countryDepartmentCitiesService.find(
      Number(countryId),
      Number(departmentId),
      query
    );
  }

  /**
   * Get Country Department City by ID
   */

  // Method and Path
  @Get(":cityId")
  // Swagger documentation
  @ApiOperation({ summary: "Get Country Department City by ID" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country Department City by id",
    type: City,
  })
  @ApiParam({ name: "countryId", example: "1" })
  @ApiParam({ name: "departmentId", example: "1" })
  @ApiParam({ name: "cityId", example: "1" })
  async getById(
    @Param("countryId") countryId: string,
    @Param("departmentId") departmentId: string,
    @Param("cityId") cityId: string,
    @Query() query: GetterByIdDto
  ) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }
    if (!departmentId || !isInteger(departmentId)) {
      throw new HttpException("Invalid ID Department", HttpStatus.BAD_REQUEST);
    }
    if (!cityId || !isInteger(cityId)) {
      throw new HttpException("Invalid ID City", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    const result = await this.countryDepartmentCitiesService.getById(
      Number(countryId),
      Number(departmentId),
      Number(cityId),
      query
    );

    if (!result) {
      throw new HttpException("Country Department City not found", HttpStatus.NOT_FOUND);
    }
    return result;
  }
}
