import { find } from "lodash";
import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { queryParse } from "@steplix/microservice/helpers";
import { FinderDto, GetterByIdDto } from "@steplix/microservice";
import { City } from "@app/entities";

//
// source code
//
@Injectable()
export class CountryDepartmentCitiesService {
  constructor(
    @InjectModel(City)
    private readonly cityModel: typeof City
  ) {}

  //
  // public
  //

  /**
   * Find All country department cities
   *
   * @param countryId {number} Unique Country Identifier
   * @param departmentId {number} Unique Country Department Identifier
   * @param query {object} Query options
   *
   * @return result {City} Result of find all country department cities
   */
  async find(countryId: number, departmentId: number, query: FinderDto) {
    const opts: any = queryParse(query);
    let department;

    // prepare

    // prepare where conditions
    opts.where = opts.where || {};
    opts.where.departmentId = departmentId;

    // prepare includes
    opts.includes = opts.includes || [];
    department = find(opts.includes, ["association", "department"]);

    if (!department) {
      opts.includes.push(
        (department = {
          association: "department",
        })
      );
    }
    department.where = department.where || {};
    department.where.countryId = countryId;

    // find country department cities
    return this.cityModel.findAll(opts);
  }

  /**
   * Get country department city by ID
   *
   * @param countryId {number} Unique Country Identifier
   * @param departmentId {number} Unique Country Department Identifier
   * @param cityId {number} Unique Country Department City Identifier
   * @param query {object} Query options
   *
   * @return result {City} Result of get country department city by ID
   */
  async getById(countryId: number, departmentId: number, cityId: number, query: GetterByIdDto) {
    const opts: any = queryParse(query);
    let department;

    // prepare

    // prepare where conditions
    opts.where = opts.where || {};
    opts.where.departmentId = departmentId;
    opts.where.id = cityId;

    // prepare includes
    opts.includes = opts.includes || [];
    department = find(opts.includes, ["association", "department"]);

    if (!department) {
      opts.includes.push(
        (department = {
          association: "department",
        })
      );
    }
    department.where = department.where || {};
    department.where.countryId = countryId;

    // get country department city
    return this.cityModel.findOne(opts);
  }
}
