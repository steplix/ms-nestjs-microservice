import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import {
  City,
  Country,
  Department,
  Status,
} from "@app/entities";
import { CountryDepartmentCitiesController } from "./controller";
import { CountryDepartmentCitiesService } from "./service";

@Module({
  imports: [
    SequelizeModule.forFeature([
      City,
      Country,
      Department,
      Status,
    ]),
  ],
  providers: [CountryDepartmentCitiesService],
  controllers: [CountryDepartmentCitiesController],
})
export class CountryDepartmentCitiesModule {}
