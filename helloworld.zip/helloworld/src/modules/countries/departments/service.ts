import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { queryParse } from "@steplix/microservice/helpers";
import { FinderDto, GetterByIdDto } from "@steplix/microservice";
import { Department } from "@app/entities";

//
// source code
//
@Injectable()
export class CountryDepartmentsService {
  constructor(
    @InjectModel(Department)
    private readonly departmentModel: typeof Department
  ) {}

  //
  // public
  //

  /**
   * Find All country departments
   *
   * @param countryId {number} Unique Country Identifier
   * @param query {object} Query options
   *
   * @return result {Department} Result of find all country department
   */
  async find(countryId: number, query: FinderDto) {
    const opts: any = queryParse(query);

    // prepare
    opts.where = opts.where || {};
    opts.where.countryId = countryId;

    // find country departments
    return this.departmentModel.findAll(opts);
  }

  /**
   * Get country department by ID
   *
   * @param countryId {number} Unique Country Identifier
   * @param departmentId {number} Unique Country Department Identifier
   * @param query {object} Query options
   *
   * @return result {Department} Result of get country department by ID
   */
  async getById(countryId: number, departmentId: number, query: GetterByIdDto) {
    const opts: any = queryParse(query);

    // prepare
    opts.where = opts.where || {};
    opts.where.id = departmentId;
    opts.where.countryId = countryId;

    // get country department
    return this.departmentModel.findOne(opts);
  }
}
