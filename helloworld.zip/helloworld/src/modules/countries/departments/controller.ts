import {
  ApiTags,
  ApiConsumes,
  ApiProduces,
  ApiResponse,
  ApiOperation,
  ApiParam,
} from "@nestjs/swagger";
import { Controller, HttpStatus, HttpException, Get, Query, Param } from "@nestjs/common";
import { FinderDto, GetterByIdDto, isInteger } from "@steplix/microservice";
import { Department } from "@app/entities";
import { CountryDepartmentsService } from "./service";

//
// class
//

// Swagger documentation
@ApiTags("country departments")
@ApiConsumes("application/json")
@ApiProduces("application/json")
// Controller name
@Controller("v1/countries/:countryId/departments")
export class CountryDepartmentsController {
  constructor(private readonly countryDepartmentsService: CountryDepartmentsService) {}

  /**
   * Find Country Departments
   */

  // Method and Path
  @Get()
  // Swagger documentation
  @ApiOperation({ summary: "Get Country Departments" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country Departments",
    type: Department,
  })
  // Interceptors
  async find(@Param("countryId") countryId: string, @Query() query: FinderDto) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    return await this.countryDepartmentsService.find(Number(countryId), query);
  }

  /**
   * Get Country Department by ID
   */

  // Method and Path
  @Get(":departmentId")
  // Swagger documentation
  @ApiOperation({ summary: "Get Country Department by ID" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country Department by id",
    type: Department,
  })
  @ApiParam({ name: "countryId", example: "1" })
  @ApiParam({ name: "departmentId", example: "1" })
  async getById(
    @Param("countryId") countryId: string,
    @Param("departmentId") departmentId: string,
    @Query() query: GetterByIdDto
  ) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }
    if (!departmentId || !isInteger(departmentId)) {
      throw new HttpException("Invalid ID Department", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    const result = await this.countryDepartmentsService.getById(
      Number(countryId),
      Number(departmentId),
      query
    );

    if (!result) {
      throw new HttpException("Country Department not found", HttpStatus.NOT_FOUND);
    }
    return result;
  }
}
