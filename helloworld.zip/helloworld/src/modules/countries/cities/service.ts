import { find } from "lodash";
import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import { queryParse } from "@steplix/microservice/helpers";
import { FinderDto, GetterByIdDto } from "@steplix/microservice";
import { City } from "@app/entities";

//
// source code
//
@Injectable()
export class CountryCitiesService {
  constructor(
    @InjectModel(City)
    private readonly cityModel: typeof City
  ) {}

  //
  // public
  //

  /**
   * Find All country cities
   *
   * @param countryId {number} Unique Country Identifier
   * @param query {object} Query options
   *
   * @return result {City} Result of find all country city
   */
  async find(countryId: number, query: FinderDto) {
    const opts: any = queryParse(query);
    let department;

    // prepare

    // prepare where conditions
    opts.where = opts.where || {};

    // prepare includes
    opts.includes = opts.includes || [];
    department = find(opts.includes, ["association", "department"]);

    if (!department) {
      opts.includes.push(
        (department = {
          association: "department",
        })
      );
    }
    department.where = department.where || {};
    department.where.countryId = countryId;

    // find country department cities
    return this.cityModel.findAll(opts);
  }

  /**
   * Get country city by ID
   *
   * @param countryId {number} Unique Country Identifier
   * @param cityId {number} Unique Country City Identifier
   * @param query {object} Query options
   *
   * @return result {City} Result of get country city by ID
   */
  async getById(countryId: number, cityId: number, query: GetterByIdDto) {
    const opts: any = queryParse(query);
    let department;

    // prepare

    // prepare where conditions
    opts.where = opts.where || {};
    opts.where.id = cityId;

    // prepare includes
    opts.includes = opts.includes || [];
    department = find(opts.includes, ["association", "department"]);

    if (!department) {
      opts.includes.push(
        (department = {
          association: "department",
        })
      );
    }
    department.where = department.where || {};
    department.where.countryId = countryId;

    // get country department city
    return this.cityModel.findOne(opts);
  }
}
