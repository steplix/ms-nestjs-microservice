import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import {
  City,
  Country,
  Department,
  Status,
} from "@app/entities";
import { CountryCitiesController } from "./controller";
import { CountryCitiesService } from "./service";

@Module({
  imports: [
    SequelizeModule.forFeature([
      City,
      Country,
      Department,
      Status,
    ]),
  ],
  providers: [CountryCitiesService],
  controllers: [CountryCitiesController],
})
export class CountryCitiesModule {}
