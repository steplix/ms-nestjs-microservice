import {
  ApiTags,
  ApiConsumes,
  ApiProduces,
  ApiResponse,
  ApiOperation,
  ApiParam,
} from "@nestjs/swagger";
import { Controller, HttpStatus, HttpException, Get, Query, Param } from "@nestjs/common";
import { FinderDto, GetterByIdDto, isInteger } from "@steplix/microservice";
import { City } from "@app/entities";
import { CountryCitiesService } from "./service";

//
// class
//

// Swagger documentation
@ApiTags("country cities")
@ApiConsumes("application/json")
@ApiProduces("application/json")
// Controller name
@Controller("v1/countries/:countryId/cities")
export class CountryCitiesController {
  constructor(private readonly countryCitiesService: CountryCitiesService) {}

  /**
   * Find Country Cities
   */

  // Method and Path
  @Get()
  // Swagger documentation
  @ApiOperation({ summary: "Get Country Cities" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country Cities",
    type: City,
  })
  // Interceptors
  async find(@Param("countryId") countryId: string, @Query() query: FinderDto) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    return await this.countryCitiesService.find(Number(countryId), query);
  }

  /**
   * Get Country City by ID
   */

  // Method and Path
  @Get(":cityId")
  // Swagger documentation
  @ApiOperation({ summary: "Get Country City by ID" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Country City by id",
    type: City,
  })
  @ApiParam({ name: "countryId", example: "1" })
  @ApiParam({ name: "cityId", example: "1" })
  async getById(
    @Param("countryId") countryId: string,
    @Param("cityId") cityId: string,
    @Query() query: GetterByIdDto
  ) {
    // Validation
    if (!countryId || !isInteger(countryId)) {
      throw new HttpException("Invalid ID Country", HttpStatus.BAD_REQUEST);
    }
    if (!cityId || !isInteger(cityId)) {
      throw new HttpException("Invalid ID City", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    const result = await this.countryCitiesService.getById(
      Number(countryId),
      Number(cityId),
      query
    );

    if (!result) {
      throw new HttpException("Country City not found", HttpStatus.NOT_FOUND);
    }
    return result;
  }
}
