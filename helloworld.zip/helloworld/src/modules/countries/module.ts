import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import {
  FinderServiceStrategy,
  GetterByIdServiceStrategy,
} from "@steplix/microservice/helpers/strategies";
import {
  City,
  Country,
  Department,
  Status,
} from "@app/entities";
import { CountriesController } from "./controller";
import { CountriesService } from "./service";
import { CountryDepartmentsModule } from "./departments";
import { CountryCitiesModule } from "./cities";

@Module({
  imports: [
    // sub-modules
    CountryDepartmentsModule,
    CountryCitiesModule,

    // db models
    SequelizeModule.forFeature([
      City,
      Country,
      Department,
      Status,
    ]),
  ],
  providers: [
    // services
    CountriesService,

    // strategies
    FinderServiceStrategy,
    GetterByIdServiceStrategy,
  ],
  controllers: [CountriesController],
})
export class CountriesModule {}
