import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import {
  FinderDto,
  GetterByIdDto,
  FinderServiceStrategy,
  GetterByIdServiceStrategy,
} from "@steplix/microservice";
import { Country } from "@app/entities";

//
// source code
//
@Injectable()
export class CountriesService {
  constructor(
    @InjectModel(Country)
    private readonly countryModel: typeof Country,
    private readonly finderServiceStrategy: FinderServiceStrategy,
    private readonly getterByIdServiceStrategy: GetterByIdServiceStrategy
  ) {}

  //
  // public
  //

  /**
   * Find All countries
   *
   * @param query {object} Query options
   *
   * @return result {Country} Result of find all countries
   */
  async find(query: FinderDto) {
    return this.finderServiceStrategy.find(this.countryModel, { query });
  }

  /**
   * Get country by ID
   *
   * @param id {number} Unique Country Identifier
   * @param query {object} Query options
   *
   * @return result {Country} Result of get country by ID
   */
  async getById(id: number, query: GetterByIdDto) {
    return this.getterByIdServiceStrategy.getById(id, this.countryModel, { query });
  }
}
