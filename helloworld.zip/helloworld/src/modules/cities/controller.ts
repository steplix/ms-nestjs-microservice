import {
  ApiTags,
  ApiConsumes,
  ApiProduces,
  ApiResponse,
  ApiOperation,
  ApiParam,
} from "@nestjs/swagger";
import {
  Controller,
  HttpStatus,
  HttpException,
  UseInterceptors,
  Get,
  Query,
  Param,
} from "@nestjs/common";
import { FinderDto, GetterByIdDto, CacheInterceptor, Cache, isInteger } from "@steplix/microservice";
import { City } from "@app/entities";
import { CitiesService } from "./service";

//
// class
//

// Swagger documentation
@ApiTags("cities")
@ApiConsumes("application/json")
@ApiProduces("application/json")
// Controller name
@Controller("v1/cities")
@UseInterceptors(CacheInterceptor)
export class CitiesController {
  constructor(private readonly citiesService: CitiesService) {}

  /**
   * Find  Cities
   */

  // Method and Path
  @Get()
  @Cache({
    time: 900000, // 15 minutes
  })
  // Swagger documentation
  @ApiOperation({ summary: "Get Cities" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get Cities",
    type: City,
  })
  async find(@Query() query: FinderDto) {
    // Bussiness logic
    return await this.citiesService.find(query);
  }

  /**
   * Get  City by ID
   */

  // Method and Path
  @Get(":id")
  @Cache({
    time: 900000, // 15 minutes
  })
  // Swagger documentation
  @ApiOperation({ summary: "Get City by ID" })
  @ApiResponse({
    status: HttpStatus.OK,
    description: "Get City by id",
    type: City,
  })
  @ApiParam({ name: "id", example: "1" })
  async getById(@Param("id") id: string, @Query() query: GetterByIdDto) {
    // Validation
    if (!id || !isInteger(id)) {
      throw new HttpException("Invalid ID City", HttpStatus.BAD_REQUEST);
    }

    // Bussiness logic
    const result = await this.citiesService.getById(Number(id), query);

    if (!result) {
      throw new HttpException("City not found", HttpStatus.NOT_FOUND);
    }
    return result;
  }
}
