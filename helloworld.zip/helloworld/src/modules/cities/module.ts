import { Module } from "@nestjs/common";
import { SequelizeModule } from "@nestjs/sequelize";
import {
  FinderServiceStrategy,
  GetterByIdServiceStrategy,
} from "@steplix/microservice/helpers/strategies";
import {
  City,
  Country,
  Department,
  Status,
} from "@app/entities";
import { CitiesController } from "./controller";
import { CitiesService } from "./service";

@Module({
  imports: [
    SequelizeModule.forFeature([
      City,
      Country,
      Department,
      Status,
    ]),
  ],
  providers: [
    // services
    CitiesService,

    // strategies
    FinderServiceStrategy,
    GetterByIdServiceStrategy,
  ],
  controllers: [CitiesController],
})
export class CitiesModule {}
