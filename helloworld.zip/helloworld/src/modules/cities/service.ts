import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/sequelize";
import {
  FinderDto,
  GetterByIdDto,
  FinderServiceStrategy,
  GetterByIdServiceStrategy,
} from "@steplix/microservice";
import { City } from "@app/entities";

//
// source code
//
@Injectable()
export class CitiesService {
  constructor(
    @InjectModel(City)
    private readonly cityModel: typeof City,
    private readonly finderServiceStrategy: FinderServiceStrategy,
    private readonly getterByIdServiceStrategy: GetterByIdServiceStrategy
  ) {}

  //
  // public
  //

  /**
   * Find All cities
   *
   * @param query {object} Query options
   *
   * @return result {City} Result of find all city
   */
  async find(query: FinderDto) {
    return this.finderServiceStrategy.find(this.cityModel, { query });
  }

  /**
   * Get city by ID
   *
   * @param id {number} Unique City Identifier
   * @param query {object} Query options
   *
   * @return result {City} Result of get city by ID
   */
  async getById(id: number, query: GetterByIdDto) {
    return this.getterByIdServiceStrategy.getById(id, this.cityModel, { query });
  }
}
