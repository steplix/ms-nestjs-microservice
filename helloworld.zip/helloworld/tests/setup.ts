// eslint-disable-next-line @typescript-eslint/no-var-requires
require("dotenv").config();

// disable the cache. Because it is not necessary to test it
process.env.NODE_ENV = "test";

// disable the cache. Because it is not necessary to test it
process.env.CACHE_ENABLED = "false";

export default async function setup () {};
