import { Test, TestingModule } from '@nestjs/testing';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { HttpStatus } from "@nestjs/common";
import { CountriesModule } from '@app/modules/countries';
import { countries, mockDatabase, mockDatabaseModule } from "../../mocks";

//
// suites
//
describe('countries', () => {

  describe('e2e', () => {
    //
    // variables
    //
    let app: NestFastifyApplication;

    //
    // hooks
    //
    beforeAll(async () => {
      const testingModule: TestingModule = await Test.createTestingModule({
        imports: [
          mockDatabaseModule(),
          CountriesModule,
        ],
      }).compile();

      app = testingModule.createNestApplication<NestFastifyApplication>(
        new FastifyAdapter(),
      );
      app.enableShutdownHooks();

      // initialize app
      await app.init();

      await mockDatabase();
    });

    afterAll(() => app.close());

    //
    // tests
    //
    it('find - endpoint /v1/countries', async () => {
      return app
        .inject({
          method: 'GET',
          url: '/v1/countries',
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(countries.length);
          expect(res).toEqual(countries);
        });
    });

    it('find - endpoint /v1/countries with pagination', async () => {
      const pageSize = 2;

      return app
        .inject({
          method: 'GET',
          url: `/v1/countries?page=1&pageSize=${pageSize}`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(pageSize);
        });
    });

    // -----------------------------------------------------------------------------

    it('getById - endpoint /v1/countries/1', async () => {
      return app
        .inject({
          method: 'GET',
          url: '/v1/countries/1',
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(typeof res === 'object').toBeTruthy();
          expect(res).toEqual(countries[0]);
        });
    });

    it('getById - endpoint /v1/countries/0 return 404', async () => {
      return app
        .inject({
          method: 'GET',
          url: '/v1/countries/0',
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.NOT_FOUND);

          const res = JSON.parse(result.payload);

          expect(res.message).toBeDefined();
          expect(res.statusCode).toBeDefined();
          expect(res.statusCode).toEqual(HttpStatus.NOT_FOUND);
        });
    });

  });

});
