import { Test, TestingModule } from '@nestjs/testing';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { HttpStatus } from "@nestjs/common";
import { CountryDepartmentsModule } from '@app/modules/countries/departments';
import { departments, mockDatabase, mockDatabaseModule } from "../../../mocks";

//
// constants
//
const countryId = 1;

//
// suites
//
describe('country departments', () => {

  describe('e2e', () => {
    //
    // variables
    //
    let app: NestFastifyApplication;

    //
    // hooks
    //
    beforeAll(async () => {
      const testingModule: TestingModule = await Test.createTestingModule({
        imports: [
          mockDatabaseModule(),
          CountryDepartmentsModule,
        ],
      }).compile();

      app = testingModule.createNestApplication<NestFastifyApplication>(
        new FastifyAdapter(),
      );
      app.enableShutdownHooks();

      // initialize app
      await app.init();

      await mockDatabase();
    });

    afterAll(() => app.close());

    //
    // tests
    //
    it(`find - endpoint /v1/countries/${countryId}/departments`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(departments.length);
          expect(res).toEqual(departments);
        });
    });

    it(`find - endpoint /v1/countries/${countryId}/departments with pagination`, async () => {
      const pageSize = 2;

      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments?page=1&pageSize=${pageSize}`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(pageSize);
        });
    });

    // -----------------------------------------------------------------------------

    it(`getById - endpoint /v1/countries/${countryId}/departments/1`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/1`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(typeof res === 'object').toBeTruthy();
          expect(res).toEqual(departments[0]);
        });
    });

    it(`getById - endpoint /v1/countries/${countryId}/departments/0 return 404`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/0`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.NOT_FOUND);

          const res = JSON.parse(result.payload);

          expect(res.message).toBeDefined();
          expect(res.statusCode).toBeDefined();
          expect(res.statusCode).toEqual(HttpStatus.NOT_FOUND);
        });
    });

  });

});
