import { CountryDepartmentCitiesService } from '@app/modules/countries/departments/cities';
import { City } from "@app/entities";
import { mockDatabase } from "../../../../mocks";

//
// constants
//
const countryId = 1;
const departmentId = 1;

//
// suites
//
describe('country department cities', () => {

  describe('service', () => {
    //
    // variables
    //
    let service: CountryDepartmentCitiesService;
    let db: any;

    //
    // hooks
    //
    beforeAll(async () => {
      service = new CountryDepartmentCitiesService(City);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      //
      // hooks
      //
      beforeAll(async () => {
        db = await mockDatabase();
      });

      afterAll(async () => {
        await db.truncate();
      });

      //
      // tests
      //
      it('should return an array with 2 cities', async () => {
        const options = {
          page: '1',
          pageSize: '2',
        };

        const result = await service.find(countryId, departmentId, options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(Number(options.pageSize));
      });

      it('should return an empty array', async () => {
        const options = {
          filters: 'description eq cuidad-de-nombre-desconocido',
        };

        const result = await service.find(countryId, departmentId, options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(0);
      });

    });

  });

});
