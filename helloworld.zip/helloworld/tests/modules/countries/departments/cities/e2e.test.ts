import { Test, TestingModule } from '@nestjs/testing';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { HttpStatus } from "@nestjs/common";
import { CountryDepartmentCitiesModule } from '@app/modules/countries/departments/cities';
import { cities, mockDatabase, mockDatabaseModule } from "../../../../mocks";

//
// constants
//
const countryId = 1;
const departmentId = 1;

//
// suites
//
describe('country department cities', () => {

  describe('e2e', () => {
    //
    // variables
    //
    let app: NestFastifyApplication;

    //
    // hooks
    //
    beforeAll(async () => {
      const testingModule: TestingModule = await Test.createTestingModule({
        imports: [
          mockDatabaseModule(),
          CountryDepartmentCitiesModule,
        ],
      }).compile();

      app = testingModule.createNestApplication<NestFastifyApplication>(
        new FastifyAdapter(),
      );
      app.enableShutdownHooks();

      // initialize app
      await app.init();

      await mockDatabase();
    });

    afterAll(() => app.close());

    //
    // tests
    //
    it(`find - endpoint /v1/countries/${countryId}/departments/${departmentId}/cities`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/${departmentId}/cities`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(cities.length);
          expect(res).toEqual(cities);
        });
    });

    it(`find - endpoint /v1/countries/${countryId}/departments/${departmentId}/cities with pagination`, async () => {
      const pageSize = 2;

      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/${departmentId}/cities?page=1&pageSize=${pageSize}`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(Array.isArray(res)).toBeTruthy();
          expect(res.length).toEqual(pageSize);
        });
    });

    // -----------------------------------------------------------------------------

    it(`getById - endpoint /v1/countries/${countryId}/departments/${departmentId}/cities/1`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/${departmentId}/cities/1`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.OK);

          const res = JSON.parse(result.payload);

          expect(typeof res === 'object').toBeTruthy();
          expect(res).toEqual(cities[0]);
        });
    });

    it(`getById - endpoint /v1/countries/${countryId}/departments/${departmentId}/cities/0 return 404`, async () => {
      return app
        .inject({
          method: 'GET',
          url: `/v1/countries/${countryId}/departments/${departmentId}/cities/0`,
        })
        .then((result) => {
          expect(result.statusCode).toBeDefined();
          expect(result.statusCode).toEqual(HttpStatus.NOT_FOUND);

          const res = JSON.parse(result.payload);

          expect(res.message).toBeDefined();
          expect(res.statusCode).toBeDefined();
          expect(res.statusCode).toEqual(HttpStatus.NOT_FOUND);
        });
    });

  });

});
