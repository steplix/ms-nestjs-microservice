import { Test, TestingModule } from '@nestjs/testing';
import { CountryDepartmentCitiesService, CountryDepartmentCitiesController } from '@app/modules/countries/departments/cities';
import { cities } from "../../../../mocks/database/data";

//
// constants
//
const countryId = "1";
const departmentId = "1";
const cityId = "1";

//
// suites
//
describe('country department cities', () => {

  describe('controller', () => {
    //
    // variables
    //
    let controller: CountryDepartmentCitiesController;
    let service: CountryDepartmentCitiesService;

    //
    // hooks
    //
    beforeEach(async () => {
      const app: TestingModule = await Test.createTestingModule({
        controllers: [CountryDepartmentCitiesController],
        providers: [
          {
            provide: CountryDepartmentCitiesService,
            useValue: {
              find: jest.fn((countryId: number, departmentId: number) => cities),
              getById: jest.fn().mockImplementation((countryId: number, departmentId: number, cityId: number) => cities[0]),
            },
          },
        ],
      }).compile();

      controller = app.get<CountryDepartmentCitiesController>(CountryDepartmentCitiesController);
      service = app.get<CountryDepartmentCitiesService>(CountryDepartmentCitiesService);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('controller - should be defined', () => {
        expect(controller).toBeDefined();
      });

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      it(`should return an array with ${cities.length} cities`, async () => {
        const result = await controller.find(countryId, departmentId, {});

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(cities.length);
        expect(service.find).toHaveBeenCalled();
        expect(service.find).toHaveBeenCalledWith(Number(countryId), Number(departmentId), {});
      });

    });

    // -----------------------------------------------------------------------------

    describe('getById', () => {

      it(`should return an object with city id [${cityId}]`, async () => {
        const result = await controller.getById(countryId, departmentId, cityId, {});

        expect(result).toBeDefined();
        expect(result).toBeInstanceOf(Object);
        expect(result).toEqual(cities[0]);
        expect(service.getById).toHaveBeenCalled();
        expect(service.getById).toHaveBeenCalledWith(Number(countryId), Number(departmentId), Number(cityId), {});
      });

    });

  });

});
