import { Test, TestingModule } from '@nestjs/testing';
import { CountryDepartmentsService, CountryDepartmentsController } from '@app/modules/countries/departments';
import { departments } from "../../../mocks/database/data";

//
// constants
//
const countryId = "1";
const departmentId = "1";

//
// suites
//
describe('country departments', () => {

  describe('controller', () => {
    //
    // variables
    //
    let controller: CountryDepartmentsController;
    let service: CountryDepartmentsService;

    //
    // hooks
    //
    beforeEach(async () => {
      const app: TestingModule = await Test.createTestingModule({
        controllers: [CountryDepartmentsController],
        providers: [
          {
            provide: CountryDepartmentsService,
            useValue: {
              find: jest.fn((countryId: number) => departments),
              getById: jest.fn().mockImplementation((countryId: number, departmentId: number) => departments[0]),
            },
          },
        ],
      }).compile();

      controller = app.get<CountryDepartmentsController>(CountryDepartmentsController);
      service = app.get<CountryDepartmentsService>(CountryDepartmentsService);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('controller - should be defined', () => {
        expect(controller).toBeDefined();
      });

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      it(`should return an array with ${departments.length} departments`, async () => {
        const result = await controller.find(countryId, {});

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(departments.length);
        expect(service.find).toHaveBeenCalled();
        expect(service.find).toHaveBeenCalledWith(Number(countryId), {});
      });

    });

    // -----------------------------------------------------------------------------

    describe('getById', () => {

      it(`should return an object with department id [${departmentId}]`, async () => {
        const result = await controller.getById(countryId, departmentId, {});

        expect(result).toBeDefined();
        expect(result).toBeInstanceOf(Object);
        expect(result).toEqual(departments[0]);
        expect(service.getById).toHaveBeenCalled();
        expect(service.getById).toHaveBeenCalledWith(Number(countryId), Number(departmentId), {});
      });

    });

  });

});
