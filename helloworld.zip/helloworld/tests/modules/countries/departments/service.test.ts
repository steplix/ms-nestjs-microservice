import { CountryDepartmentsService } from '@app/modules/countries/departments';
import { Department } from "@app/entities";
import { mockDatabase } from "../../../mocks";

//
// constants
//
const countryId = 1;

//
// suites
//
describe('country departments', () => {

  describe('service', () => {
    //
    // variables
    //
    let service: CountryDepartmentsService;
    let db: any;

    //
    // hooks
    //
    beforeAll(async () => {
      service = new CountryDepartmentsService(Department);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      //
      // hooks
      //
      beforeAll(async () => {
        db = await mockDatabase();
      });

      afterAll(async () => {
        await db.truncate();
      });

      //
      // tests
      //
      it('should return an array with 2 departments', async () => {
        const options = {
          page: '1',
          pageSize: '2',
        };

        const result = await service.find(countryId, options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(Number(options.pageSize));
      });

      it('should return an empty array', async () => {
        const options = {
          filters: 'description eq departamento-de-nombre-desconocido',
        };

        const result = await service.find(countryId, options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(0);
      });

    });

  });

});
