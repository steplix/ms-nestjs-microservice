import { FinderServiceStrategy, GetterByIdServiceStrategy } from "@steplix/microservice";
import { CountriesService } from '@app/modules/countries';
import { Country } from "@app/entities";
import { mockDatabase } from "../../mocks";

//
// suites
//
describe('countries', () => {

  describe('service', () => {
    //
    // variables
    //
    let service: CountriesService;
    let db: any;

    //
    // hooks
    //
    beforeAll(async () => {
      service = new CountriesService(Country, new FinderServiceStrategy(), new GetterByIdServiceStrategy());
    });

    //
    // tests
    //
    describe('definition', () => {

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      //
      // hooks
      //
      beforeAll(async () => {
        db = await mockDatabase();
      });

      afterAll(async () => {
        await db.truncate();
      });

      //
      // tests
      //
      it('should return an array with 2 countries', async () => {
        const options = {
          page: '1',
          pageSize: '2',
        };

        const result = await service.find(options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(Number(options.pageSize));
      });

      it('should return an empty array', async () => {
        const options = {
          filters: 'description eq pais-de-nombre-desconocido',
        };

        const result = await service.find(options);

        console.log(result)

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(0);
      });

    });

  });

});
