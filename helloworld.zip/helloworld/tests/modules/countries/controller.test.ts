import { Test, TestingModule } from '@nestjs/testing';
import { CountriesService, CountriesController } from '@app/modules/countries';
import { countries } from "../../mocks/database/data";

//
// constants
//
const countryId = "1";

//
// suites
//
describe('countries', () => {

  describe('controller', () => {
    //
    // variables
    //
    let controller: CountriesController;
    let service: CountriesService;

    //
    // hooks
    //
    beforeEach(async () => {
      const app: TestingModule = await Test.createTestingModule({
        controllers: [CountriesController],
        providers: [
          {
            provide: CountriesService,
            useValue: {
              find: jest.fn(() => countries),
              getById: jest.fn().mockImplementation((id: number) => countries[0]),
            },
          },
        ],
      }).compile();

      controller = app.get<CountriesController>(CountriesController);
      service = app.get<CountriesService>(CountriesService);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('controller - should be defined', () => {
        expect(controller).toBeDefined();
      });

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      it(`should return an array with ${countries.length} countries`, async () => {
        const result = await controller.find({});

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(countries.length);
        expect(service.find).toHaveBeenCalled();
      });

    });

    // -----------------------------------------------------------------------------

    describe('getById', () => {

      it(`should return an object with city id [${countryId}]`, async () => {
        const result = await controller.getById(countryId, {});

        expect(result).toBeDefined();
        expect(result).toBeInstanceOf(Object);
        expect(result).toEqual(countries[0]);
        expect(service.getById).toHaveBeenCalled();
        expect(service.getById).toHaveBeenCalledWith(Number(countryId), {});
      });

    });

  });

});
