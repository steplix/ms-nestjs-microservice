import { Test, TestingModule } from '@nestjs/testing';
import { CitiesService, CitiesController } from '@app/modules/cities';
import { cities } from "../../mocks/database/data";

//
// constants
//
const cityId = "1";

//
// suites
//
describe('cities', () => {

  describe('controller', () => {
    //
    // variables
    //
    let controller: CitiesController;
    let service: CitiesService;

    //
    // hooks
    //
    beforeEach(async () => {
      const app: TestingModule = await Test.createTestingModule({
        controllers: [CitiesController],
        providers: [
          {
            provide: CitiesService,
            useValue: {
              find: jest.fn().mockImplementation(() => cities),
              getById: jest.fn().mockImplementation((id: number) => cities[0]),
            },
          },
        ],
      }).compile();

      controller = app.get<CitiesController>(CitiesController);
      service = app.get<CitiesService>(CitiesService);
    });

    //
    // tests
    //
    describe('definition', () => {

      it('controller - should be defined', () => {
        expect(controller).toBeDefined();
      });

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      it(`should return an array with ${cities.length} cities`, async () => {
        const result = await controller.find({});

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(cities.length);
        expect(service.find).toHaveBeenCalled();
      });

    });

    // -----------------------------------------------------------------------------

    describe('getById', () => {

      it(`should return an object with city id [${cityId}]`, async () => {
        const result = await controller.getById(cityId, {});

        expect(result).toBeDefined();
        expect(result).toBeInstanceOf(Object);
        expect(result).toEqual(cities[0]);
        expect(service.getById).toHaveBeenCalled();
        expect(service.getById).toHaveBeenCalledWith(Number(cityId), {});
      });

    });

  });

});
