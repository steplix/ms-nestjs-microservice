import { FinderServiceStrategy, GetterByIdServiceStrategy } from "@steplix/microservice";
import { CitiesService } from '@app/modules/cities';
import { City } from "@app/entities";
import { mockDatabase } from "../../mocks";

//
// suites
//
describe('cities', () => {

  describe('service', () => {
    //
    // variables
    //
    let service: CitiesService;
    let db: any;

    //
    // hooks
    //
    beforeAll(async () => {
      service = new CitiesService(City, new FinderServiceStrategy(), new GetterByIdServiceStrategy());
    });

    //
    // tests
    //
    describe('definition', () => {

      it('service - should be defined', () => {
        expect(service).toBeDefined();
      });

    });

    // -----------------------------------------------------------------------------

    describe('find', () => {

      //
      // hooks
      //
      beforeAll(async () => {
        db = await mockDatabase();
      });

      afterAll(async () => {
        await db.truncate();
      });

      //
      // tests
      //
      it('should return an array with 2 cities', async () => {
        const options = {
          page: '1',
          pageSize: '2',
        };

        const result = await service.find(options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(Number(options.pageSize));
      });

      it('should return an empty array', async () => {
        const options = {
          filters: 'description eq cuidad-de-nombre-desconocido',
        };

        const result = await service.find(options);

        expect(result).toBeDefined();
        expect(Array.isArray(result)).toBeTruthy();
        expect(result.length).toEqual(0);
      });

    });

  });

});
