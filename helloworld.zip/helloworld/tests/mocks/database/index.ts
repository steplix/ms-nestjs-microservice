import * as entities from "@app/entities";
import { trues } from "@steplix/microservice/constants";
import { logger } from "@steplix/microservice/helpers/logger";
import { SequelizeModule, SequelizeModuleOptions } from '@nestjs/sequelize';
import { ModelCtor, Sequelize, SequelizeOptions } from 'sequelize-typescript';
import { cities, countries, departments, statuses } from './data';

//
// constants
//
const models: ModelCtor[] = Object.values(entities);
const sequelizeOptions: SequelizeOptions = {
  dialect: 'sqlite',
  storage: ':memory:',
  logging: trues.includes(String(process.env.DB_DEBUG).toLowerCase()),
};

//
// public
//

/**
 * Emulate database module
 */
export const mockDatabaseModule = async (): Promise<any> => {
  return SequelizeModule.forRoot({
    ...sequelizeOptions,
    models,
    synchronize: true,
  } as SequelizeModuleOptions);
};

/**
 * Emulate database instance object
 *
 * @param initializeBaseData {boolean} Indicate if is necesary insert base data
 *
 * @return Sequelize instance
 */
export const mockDatabase = async (initializeBaseData: boolean = true): Promise<Sequelize> => {
  const databaseInMemory = new Sequelize(sequelizeOptions);

  // attach models
  databaseInMemory.addModels(models);

  // creates the database structure
  await databaseInMemory.sync();

  if (initializeBaseData) {
    // insert base data
    await insertBaseData();
  }

  return databaseInMemory;
};

/**
 * Insert all base data for tests
 */
export const insertBaseData = async () => {
  await insertBaseDataForModel(entities.Status, statuses);
  await insertBaseDataForModel(entities.Country, countries);
  await insertBaseDataForModel(entities.Department, departments);
  await insertBaseDataForModel(entities.City, cities);
};

/**
 * Reexport all base data objects
 */
export * from './data';

//
// private
//

const insertBaseDataForModel = async (model: ModelCtor, data: any[]) => {
  for (const item of data) {
    try {
      await model.create(item as any);
    }
    catch (e) {
      logger.error(`Error on inser base data for model ${model.name}`, e);
      throw e;
    }
  }
};
