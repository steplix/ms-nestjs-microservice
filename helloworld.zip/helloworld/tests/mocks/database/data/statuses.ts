export const statuses = [
  {
    id: 1,
    description: "active"
  },
  {
    id: 2,
    description: "inactive"
  }
];
