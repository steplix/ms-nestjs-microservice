export const countries = [
  {
    id: 1,
    statusId: 1,
    description: "Colombia",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-26T08:55:54.000Z"
  },
  {
    id: 2,
    statusId: 1,
    description: "México",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-26T08:54:56.000Z"
  },
  {
    id: 3,
    statusId: 1,
    description: "Chile",
    createdAt: "2021-01-04T13:00:12.000Z",
    updatedAt: "2022-09-26T08:14:26.000Z"
  },
  {
    id: 4,
    statusId: 2,
    description: "USA",
    createdAt: "2021-07-09T16:24:20.000Z",
    updatedAt: "2022-09-23T18:43:08.000Z"
  }
];
