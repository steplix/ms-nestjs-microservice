export const cities = [
  {
    id: 1,
    statusId: 2,
    departmentId: 1,
    description: "Giron",
    createdAt: "2022-09-26T08:55:54.000Z",
    updatedAt: "2022-09-26T08:55:54.000Z"
  },
  {
    id: 2,
    statusId: 1,
    departmentId: 1,
    description: "Piedecuesta",
    createdAt: "2022-09-26T08:54:56.000Z",
    updatedAt: "2022-09-26T08:54:56.000Z"
  },
  {
    id: 3,
    statusId: 1,
    departmentId: 1,
    description: "Jamundi",
    createdAt: "2022-09-26T08:14:26.000Z",
    updatedAt: "2022-09-26T08:14:26.000Z"
  },
  {
    id: 4,
    statusId: 1,
    departmentId: 1,
    description: "Yumbo",
    createdAt: "2022-09-23T18:43:08.000Z",
    updatedAt: "2022-09-23T18:43:08.000Z"
  }
];
