export const departments = [
  {
    id: 1,
    countryId: 1,
    statusId: 1,
    description: "VICHADA",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-26T08:55:54.000Z"
  },
  {
    id: 2,
    countryId: 1,
    statusId: 1,
    description: "VAUPÉS",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-26T08:54:56.000Z"
  },
  {
    id: 3,
    countryId: 1,
    statusId: 1,
    description: "GUAVIARE",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-26T08:14:26.000Z"
  },
  {
    id: 4,
    countryId: 1,
    statusId: 1,
    description: "GUAINÍA",
    createdAt: "2020-06-16T22:25:16.000Z",
    updatedAt: "2022-09-23T18:43:08.000Z"
  }
];
