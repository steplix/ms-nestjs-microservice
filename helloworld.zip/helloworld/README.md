<div id="top"></div>

# Micro Servicio de locations (*Hello World - NestJS library*)

API RESTful que se utiliza para manejar todo lo relacionado con los paises, estados/provincias y ciudades.


## Index

* [Descargar][descargar].
* [Configuraciones][configuraciones].
* [Base de datos][base_de_datos].
* [¿Cómo se corre?][como_se_corre].
* [Endpoints][endpoints].
* [Tests][tests].


## Descargar

### Código fuente
```shell
$ git clone git@gitlab.com/steplix/helloworld.git
$ cd helloworld
$ npm i
```

<p align="right">(<a href="#top">ir arriba</a>)</p>


## Configuraciones

Cada Micro Servicio cuenta con un archivo `.env.example`. En el mismo, se encuentran las configuraciones mínimas para poder correr dicho MS.

Para que el MS levante dichas configuraciones, es necesario correr el siguiente comando,
```shell
$ cp .env.example .env
```

> 💡 NOTA: Para visualizar todas las configuraciones posibles, ingresar al siguiente [link][https://gitlab.com/steplix/nestjs-microservice#configure]

<p align="right">(<a href="#top">ir arriba</a>)</p>


## Base de datos

Cada Micro Servicio tiene su propia base de datos. La misma se encuentra en el root, dentro de la carpeta `database`. 
Aquí mostramos algunos comandos útiles,

### Instalar DB

```shell
# Instalar la base de datos en el entorno local, con las credenciales de conexión predeterminadas.
npm run db:install

#
# Instalar la base de datos con las credenciales de customizadas.
npm run db:install -- --host=docker.mysql.host --user=admin --pass=1234abcd
#
# o
DB_HOST=docker.mysql.host DB_USER=admin DB_PASS=1234abcd npm run db:install

#
# Para mas detalles, correr
npm run db:install -- --help
```

> Valores por defecto
>  - DB Name -> `steplix_locations`
>  - DB Host -> `localhost`
>  - DB User -> `root`
>  - DB User -> `WwFFTRDJ7s2RgPWx`


<p align="right">(<a href="#top">ir arriba</a>)</p>


## ¿Cómo se corre?

### Correr

Crear un archivo `.env` y copie las variables de entorno requeridas según el archivo `.env.*` que corresponda. Luego ejecute uno de los siguientes comandos:

```shell
# Desarrollo
npm run dev

# Producción
npm run build && npm start
```

<p align="right">(<a href="#top">ir arriba</a>)</p>


## Endpoints
* `GET` [/health](#) Health check.
* `GET` [/api/v1/countries](#) Listar/filtrar las paises.
* `GET` [/api/v1/countries/:id](#) Obteneruna país por su identificador único (ID).
* `GET` [/api/v1/countries/:idCountry/departments](#) Listar/filtrar los estados/provincias de un determinado país.
* `GET` [/api/v1/countries/:idCountry/departments/:idDepartment](#) Obtener un estado/provincia, de un determinado país, por su identificador único (ID).
* `GET` [/api/v1/countries/:idCountry/departments/:idDepartment/cities](#) Listar/filtrar las ciudades de un determinado país y departamento.
* `GET` [/api/v1/countries/:idCountry/departments/:idDepartment/cities/:idCity](#) Obtener una ciudad, de un determinado país y departamento, por su identificador único (ID).
* `GET` [/api/v1/countries/:idCountry/cities](#) Listar/filtrar las ciudades de un determinado país.
* `GET` [/api/v1/countries/:idCountry/cities/:idCity](#) Obtener una ciudad, de un determinado país, por su identificador único (ID).
* `GET` [/api/v1/cities](#) Listar/filtrar las ciudades.
* `GET` [/api/v1/cities/:idCity](#) Obtener una ciudad por su identificador único (ID).

<p align="right">(<a href="#top">ir arriba</a>)</p>


## Tests

Para ver ejemplos más concretos, **LOS INVITO A VER LAS PRUEBAS :)**

### Ejecutar las pruebas unitarias
```shell
npm test
```

<!-- deep links -->
[descargar]: #descargar
[configuraciones]: #configuraciones
[base_de_datos]: #base-de-datos
[como_se_corre]: #cómo-se-corre
[endpoints]: #endpoints
[tests]: #tests
