# ================================================================================================
# Database Locations
# ================================================================================================

USE `steplix_locations`;

# ================================================================================================
# locations
# ================================================================================================

LOCK TABLES `statuses` WRITE;
/*!40000 ALTER TABLE `statuses` DISABLE KEYS */;
INSERT INTO `statuses` VALUES
  (1, 'active'),
  (2, 'inactive');
/*!40000 ALTER TABLE `statuses` ENABLE KEYS */;
UNLOCK TABLES;

# ================================================================================================

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES
  (1, 1, 'Colombia', NOW(), NULL),
  (2, 1, 'México', NOW(), NULL),
  (3, 1, 'Chile', NOW(), NULL),
  (4, 1, 'USA', NOW(), NULL);
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

# ================================================================================================

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES
  (1, 1, 1, 'CUNDINAMARCA', NOW(), NULL),
  (2, 1, 1, 'ANTIOQUÍA', NOW(), NULL),
  (3, 1, 2, 'MÉXICO', NOW(), NULL),
  (4, 1, 3, 'CHILE', NOW(), NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

# ================================================================================================

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES
  (1, 1, 1, 'Bogotá D.C.', NOW(), NULL),
  (2, 1, 1, 'Chia', NOW(), NULL),
  (3, 1, 2, 'Medellín', NOW(), NULL),
  (4, 1, 2, 'Abriaquí', NOW(), NULL),
  (5, 1, 3, 'CDMX y Área Metropolitana', NOW(), NULL),
  (6, 1, 3, 'Monterrey y Área Metropolitana', NOW(), NULL),
  (7, 1, 4, 'Santiago de Chile', NOW(), NULL);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;
